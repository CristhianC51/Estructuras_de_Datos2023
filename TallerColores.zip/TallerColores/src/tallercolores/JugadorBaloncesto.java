package tallercolores;

public class JugadorBaloncesto {
    private String pantalonColor;
    private String balonColor;
    private String zapatosColor;
    private String nombre;

    public JugadorBaloncesto(String pantalonColor, String balonColor, String zapatosColor, String nombre) {
        this.pantalonColor = pantalonColor;
        this.balonColor = balonColor;
        this.zapatosColor = zapatosColor;
        this.nombre = nombre;
    }
    
    public String getPantalonColor() {
        return pantalonColor;
    }

    public void setPantalonColor(String pantalonColor) {
        this.pantalonColor = pantalonColor;
    }

    public String getBalonColor() {
        return balonColor;
    }

    public void setBalonColor(String balonColor) {
        this.balonColor = balonColor;
    }

    public String getZapatosColor() {
        return zapatosColor;
    }

    public void setZapatosColor(String zapatosColor) {
        this.zapatosColor = zapatosColor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public void caminar() {
        System.out.println("El jugador " + nombre + " esta caminando");
    }
    
    public void saltar() {
        System.out.println("El jugador " + nombre + " esta saltando");
    }
    
    public void lanzarBalon() {
        System.out.println("El jugador " + nombre + " lanzo el balon y anoto!");
    }
    
    public void correr() {
        System.out.println("El jugador " + nombre + " esta corriendo");
    }
    
    public void descansar() {
        System.out.println("El jugador " + nombre + " esta descansando");
    }
}
