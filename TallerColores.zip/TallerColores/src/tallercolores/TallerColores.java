package tallercolores;

public class TallerColores {

    public static void main(String[] args) {
        JugadorBaloncesto j1 = new JugadorBaloncesto("Azul oscuro", "Azul claro", "Azul combinado con azul oscuro y claro", "Ramiro");
        j1.caminar();
        j1.descansar();
        j1.correr();
    }
}